window.TL = {
    url: "https://www.thinglink.com/card/1214934907906686981"
};
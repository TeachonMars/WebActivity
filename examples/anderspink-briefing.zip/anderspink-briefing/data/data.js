window.AP = {
    briefingId: "530",
    points: 5
};
window.TL = {
    url: "https://www.thinglink.com/videocard/1214934908426780677",
    points: 0
};